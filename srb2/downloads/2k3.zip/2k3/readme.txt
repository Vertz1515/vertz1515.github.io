Sonic Robo Blast 2: 2003
http://www.srb2.org
------------------------

What is this?

SRB2:2k3, aside from its name being a cheap spoof on Unreal,
is a SAGE-exclusive, netplay-only beta test of SRB2. This is
why "1 Player" does not function. If you've been hammering
the 1 Player menu for 2 hours now and only just read this, I
pity you.

I'm sorry, but there is no MIDI support for this release. I
just didn't have enough time to insert all the proper MIDIs.
Just use -nomusic and -nodigmusic if you wish to play in silence.

I think just about everything is self-explanatory. Except:

Game Modes:

Coop - Well, since there are no single player levels, this is
irrelevant.

Match - Your basic DM. Combine the weapons for some interesting
results.

Race - Well, since there are no single player levels, this is
irrelevant.

Tag - Kind of like Match, but only one person is "it".

CTF - Sometimes it works, sometimes it doesn't. You're welcome
to give it a shot. Capture the other team's flag while defending
your own.

Chaos - Each player competes against each other to obtain the
highest baddie-killing score.


Explore the option menus... you'll find interesting stuff!

I even included a little unfinished thing. Maybe you'll find it!